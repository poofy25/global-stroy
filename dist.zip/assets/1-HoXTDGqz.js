const s="/assets/1-FQzQwWZT.png";export{s as default};
