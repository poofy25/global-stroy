const s="/assets/1-dk9xvSIi.png";export{s as default};
