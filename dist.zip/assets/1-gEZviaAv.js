const s="/assets/1-OPW0XJrP.png";export{s as default};
