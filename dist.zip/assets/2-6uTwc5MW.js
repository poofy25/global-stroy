const s="/assets/2-OLQHEvln.png";export{s as default};
