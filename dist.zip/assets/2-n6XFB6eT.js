const s="/assets/2-CNmJbuIR.png";export{s as default};
