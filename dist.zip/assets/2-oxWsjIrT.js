const s="/assets/2-LbZwOWML.png";export{s as default};
