const s="/assets/3-wzHmhfiO.png";export{s as default};
