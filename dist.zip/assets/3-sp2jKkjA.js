const s="/assets/3-Lqvse5-M.png";export{s as default};
