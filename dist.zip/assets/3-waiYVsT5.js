const s="/assets/3-HD7ijKE2.png";export{s as default};
