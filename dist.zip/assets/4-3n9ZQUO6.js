const s="/assets/4-67LK0sME.png";export{s as default};
