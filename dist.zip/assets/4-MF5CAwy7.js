const s="/assets/4-s66zO3NX.png";export{s as default};
