const s="/assets/4-kT6I9Snj.png";export{s as default};
