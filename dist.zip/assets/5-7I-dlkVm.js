const s="/assets/5-DcBaKSyv.png";export{s as default};
