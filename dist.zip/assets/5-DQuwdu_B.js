const s="/assets/5-ZbiymYaU.png";export{s as default};
