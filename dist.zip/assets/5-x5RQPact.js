const s="/assets/5-zUwzglJ6.png";export{s as default};
