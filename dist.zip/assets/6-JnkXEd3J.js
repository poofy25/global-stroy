const s="/assets/6-pwN6Xdra.png";export{s as default};
