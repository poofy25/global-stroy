const s="/assets/6-bsXS_SS8.png";export{s as default};
