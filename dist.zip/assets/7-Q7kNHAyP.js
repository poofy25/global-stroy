const s="/assets/7-uf-NQ5Th.png";export{s as default};
